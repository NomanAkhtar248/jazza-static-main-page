import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu"
import Link from "next/link"
import { Zap } from "lucide-react"
import Image from "next/image"
import NavMenuLink from "../nav-menu-link"

const categories = [
  {
    name: "Hot Deals",
    imageUrl: "/hotdeal.webp",
  },
  {
    name: "iPhone",
    items: [
      "iPhone 15 Series",
      "iPhone 14 Series",
      "iPhone 13 Series",
      "iPhone 12 Series",
      "iPhone 11 Series",
      "iPhone SE Series",
      "iPhone X Series",
      "iPhone 8 Series",
      "iPhone 7 Series",
    ],
  },
  {
    name: "Samsung",
    items: [
      "Galaxy 8 Series",
      "Galaxy S10 Series",
      "Galaxy S20 Series",
      "Galaxy S21 Series",
      "Galaxy S22 Series",
      "Galaxy S23 Series",
      "Galaxy Note Series",
      "Galaxy Z Series",
    ],
  },
  {
    name: "MacBook",
    items: ["Macbook Pro", "Macbook Air", "Apple iMac"],
  },
  {
    name: "Laptops",
    items: ["Dell", "Lenovo", "HP", "Microsoft", "Acer", "Samsung"],
  },
  {
    name: "Ipads",
    // no items
  },
  {
    name: "Apple Watches",
    // no items
  },
  {
    name: "Gaming",
    // no items
  },
  {
    name: "For Businesses",
    // no items
  },
  {
    name: "Help",
    items: [
      "Help Center & FAQ",
      "Track Your Order",
      "Raise A Claim",
      "Track Your Claim",
    ],
  },
  {
    name: "Revibe Express",
    icon: Zap,
  },
]

const NavMenu = () => {
  return (
    <div className="hidden xl:block">
      <div className="w-full border-b bg-white px-6">
        <div className="w-full">
          <NavigationMenu
            // viewport={false}
            className="max-w-none w-full justify-start [&>div]:justify-start [&>div]:w-full"
          >
            <NavigationMenuList className="flex flex-nowrap justify-between px-4 sm:px-6 lg:px-8 w-full">
              {categories.map((category, index) => {
                const isLast = index === categories.length - 1
                const hasItems =
                  Array.isArray(category.items) && category.items.length > 0

                // If category has items, show trigger + dropdown

                if (hasItems) {
                  return (
                    <NavigationMenuItem key={index}>
                      <NavigationMenuTrigger className="bg-transparent hover:!text-[#7f19a0] hover:!bg-transparent [&>svg]:hidden  whitespace-nowrap data-[state=open]:bg-transparent">
                        <div className="flex items-center gap-2">
                          <span className="font-montserrat font-semibold cursor-pointer">
                            {category.name}
                          </span>
                        </div>
                      </NavigationMenuTrigger>

                      {/*  Use your custom component here */}

                      <NavigationMenuContent>
                        <ul className="grid w-[200px] gap-2  p-0 m-0">
                          {category.items?.map((itemName, i) => (
                            <li key={i}>
                              <NavMenuLink
                                itemName={itemName}
                                isLast={i === category.items.length - 1}
                              />
                            </li>
                          ))}
                        </ul>
                      </NavigationMenuContent>
                    </NavigationMenuItem>
                  )
                }

                // Else, show simple link (no dropdown at all)
                return (
                  <NavigationMenuItem key={index}>
                    <NavigationMenuLink
                      asChild
                      className={navigationMenuTriggerStyle()}
                    >
                      <Link
                        href="#"
                        className={`flex items-center gap-2 whitespace-nowrap hover:!text-[#7f19a0] hover:bg-transparent ${
                          isLast
                            ? "text-[#7f19a0] hover:!text-[#7f19a0] hover:bg-transparent "
                            : ""
                        }`}
                      >
                        {/* Wrap both name + icon + image in flex */}
                        <span className="flex items-center gap-1 font-montserrat font-semibold ">
                          {category.name}

                          {/* Icon (like Revibe Express) */}

                          {category.icon &&
                            (() => {
                              const Icon = category.icon
                              return (
                                <Icon className="h-4 w-4 text-[#7f19a0]  fill-[#7f19a0] stroke-[#7f19a0]" />
                              )
                            })()}

                          {/* Image (like Hot Deals) */}

                          {category.imageUrl && (
                            <Image
                              src={category.imageUrl}
                              alt={category.name}
                              width={30}
                              height={30}
                              className="object-contain cursor-pointer"
                            />
                          )}
                        </span>
                      </Link>
                    </NavigationMenuLink>
                  </NavigationMenuItem>
                )
              })}
            </NavigationMenuList>
          </NavigationMenu>
        </div>
      </div>
    </div>
  )
}

export default NavMenu
