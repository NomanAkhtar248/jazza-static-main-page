import { Zap } from "lucide-react"

const PromoNavbar = () => {
  return (
    <div className="h-6 md:h-8 bg-[#c82d8c] flex justify-center md:justify-between items-center">
      <div className="text-white sm:text-center font-semibold">
        FREE DELIVERY ON ALL ORDERS
      </div>
      <div className="hidden md:flex items-center space-x-5  ">
        <span className="text-yellow-400 cursor-pointer font-semibold flex items-center gap-1">
          <Zap />
          Sale
        </span>
        <span className="text-white cursor-pointer hover:text-blue-500 font-semibold">
          Track Order
        </span>
        <span className="text-white cursor-pointer hover:text-blue-500 font-semibold">
          Contact
        </span>
      </div>
    </div>
  )
}

export default PromoNavbar
