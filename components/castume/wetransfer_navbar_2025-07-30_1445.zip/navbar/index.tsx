import Image from "next/image"
import { AlignJustify } from "lucide-react"
import NavSearch from "../../components/nav-search"
import NavIcons from "../../components/nav-icons"

const Navbar = () => {
  return (
    <section className="py-3 xl:py-4 bg-white border-b-1 border-[#ddd]">
      <div className="xl:px-16 px-2">
        <nav className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4 w-full">
          {/*  Logo + Hamburger + Icons (for sm/md/lg) */}
          <div className="flex items-center justify-between w-full md:hidden">
            <AlignJustify size={26} />
            <Image
              src="/logo.png"
              alt="logo"
              width={70}
              height={70}
              className="cursor-pointer "
            />
            <div className="flex gap-2">
              <NavIcons />
            </div>
          </div>

          {/* show only on md and lg  sereen */}
          <div className="hidden md:flex xl:hidden items-center justify-between w-full">
            <AlignJustify size={26} />
            <Image
              src="/logo.png"
              alt="logo"
              width={100}
              height={100}
              className="cursor-pointer  "
            />
            <div className="flex gap-2">
              <NavIcons />
            </div>
          </div>

          {/*  Logo (xl only) */}
          <div className="hidden xl:flex items-center gap-2">
            {/* Removed aspect-auto from parent div */}
            <Image
              src="/logo.png"
              alt="logo"
              width={180}
              height={100}
              sizes="(min-width: 1280px) 180px, 100vw"
              className="cursor-pointer object-contain"
              priority // Added priority prop for immediate loading and CLS prevention
            />
          </div>

          {/*  Searchbar – 2nd row on sm/md/lg */}
          <div className="w-full xl:hidden">
            <NavSearch />
          </div>

          {/*  Searchbar – inline on xl */}
          <div className="hidden xl:block w-full">
            <NavSearch />
          </div>

          {/*  Icons only for xl and up */}
          <div className="hidden xl:flex gap-2">
            <NavIcons />
          </div>
        </nav>
      </div>
    </section>
  )
}

export default Navbar
