import NavMenu from "../../components/nav-menu"
import PromoNavbar from "../../components/promo-navbar"
import Navbar from "../navbar"

const Header = () => {
  return (
    <div className="sticky top-0 z-50">
      <PromoNavbar />
      <Navbar />
      <NavMenu />
    </div>
  )
}

export default Header
