import { UserRound } from "lucide-react"

const Account = () => {
  return (
    <div className="flex flex-row items-center lg:space-x-2 group">
      <span className="flex items-center justify-center cursor-pointer">
        <UserRound
          size={24}
          className="text-gray-700 transition-transform duration-300 group-hover:text-[#c82d8c] group-hover:scale-110"
        />
      </span>

      <div className="hidden xl:flex flex-col items-start">
        <span className="text-sm font-medium text-gray-800 group-hover:text-[#c82d8c] cursor-pointer">
          My Account
        </span>
        <span className="text-sm text-gray-600 group-hover:text-[#c82d8c] cursor-pointer">
          fazisb456
        </span>
      </div>
    </div>
  )
}

export default Account
