import { ShoppingCart } from "lucide-react"

const Cart = ({ itemCount = 0 }) => {
  return (
    <div className="flex flex-row items-center  group ">
      <span className="relative flex items-center justify-center cursor-pointer">
        <ShoppingCart
          size={24}
          className="text-gray-700 transition-transform duration-300 group-hover:text-[#c82d8c] group-hover:scale-110"
        />

        <span className="absolute -top-3 -right-2 text-[10px] px-1.5 py-[4px] rounded-full bg-[#c82d8c] text-white font-semibold leading-none group-hover:scale-110 transition-transform">
          {itemCount}
        </span>
      </span>
    </div>
  )
}

export default Cart
