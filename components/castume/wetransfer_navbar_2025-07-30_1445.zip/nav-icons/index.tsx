import Help from "./help"
import Account from "./account"
import Wishlist from "./wishlist"
import Cart from "./cart"

const NavIcons = () => {
  return (
    <div className="flex items-center gap-1  whitespace-nowrap">
      <Help />
      <Account />
      <Wishlist />
      <Cart />
    </div>
  )
}

export default NavIcons
