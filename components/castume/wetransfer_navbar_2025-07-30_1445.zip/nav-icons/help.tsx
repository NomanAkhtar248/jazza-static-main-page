import { Headset } from "lucide-react"

const Help = () => {
  return (
    <div className="flex flex-row items-center lg:space-x-2 group">
      <a
        href="tel:+97143487362"
        className="flex items-center justify-center group-hover:text-[#c82d8c] cursor-pointer"
        aria-label="Call +97143487362 for help"
      >
        <Headset
          size={24}
          className="text-gray-700 transition-transform duration-300 group-hover:text-[#c82d8c] group-hover:scale-110"
        />
        <div className="hidden lg:flex flex-col items-start">
          <span className="text-sm font-medium text-gray-800 group-hover:text-[#c82d8c] cursor-pointer">
            Need Help?
          </span>
          <span
            className="text-sm text-gray-600 group-hover:text-[#c82d8c] cursor-pointer"
            aria-label="Call +97143487362 for help"
          >
            +97143487362
          </span>
        </div>
      </a>
    </div>
  )
}

export default Help
